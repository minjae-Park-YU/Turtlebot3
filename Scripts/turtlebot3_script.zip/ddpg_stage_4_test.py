#!/home/ubuntu/anaconda3/envs/tbtorch/bin/python3
# Authors: Junior Costa de Jesus #
# Deveoper: Minjae Park #

import rospy
import os
import numpy as np
import random
import time
import sys
import copy
import pandas as pd
import torch
import torch.nn.functional as F
import torch.nn as nn

from collections import deque
from std_msgs.msg import Float32
from environment_stage_4 import Env
from collections import deque

# (22.08.11 park) 사용 파라미터 한번에 관리하도록 구조 변경
# (22.07.21 park) reward 쉽게 변경하도록 모드 설정
experiment = "ddpg_original"

exploration_decay_rate = 0.001
BATCH_SIZE = 2000  # 256 * 2
LEARNING_RATE = 0.001
GAMMA = 0.99
TAU = 0.001

ENSEMBLE = 0
EPISODE = 0
MAX_EPISODES = 100
MAX_STEPS = 300
rewards_all_episodes = []

EPS = 0.003 # Critic weight 초기화 관련 파라미터

ACTION_DIMENSION = 2
ACTION_V_MAX = 0.22  # m/s
ACTION_W_MAX = 2.    # rad/s

# (22.07.22 kwon) 성공/충돌 시 보상 변수로 설정
# goal reward / collision reward
goal_reward = 500
collision_reward = -550

# (22.08.11 park) Stage 별 파라미터 변경하도록 함
world = 'stage_4'
SCAN_RANGE = 10
STATE_DIMENSION = SCAN_RANGE + ACTION_DIMENSION + 4

if reward_mode == 1:
    print("******************* reward mode : ", reward_dict[1], " ********************")
if reward_mode == 2:
    print("******************* reward mode : ", reward_dict[2], " ********************")
if reward_mode == 3:
    print("******************* reward mode : ", reward_dict[3], " ********************")


# ---Directory Path---#
dirPath = os.path.dirname(os.path.realpath(__file__))


# ---Functions to make network updates---#

def soft_update(target, source, tau):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)


def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)


# ---Critic--#

def fanin_init(size, fanin=None):
    fanin = fanin or size[0]
    v = 1. / np.sqrt(fanin)
    return torch.Tensor(size).uniform_(-v, v)


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()

        self.state_dim = state_dim = state_dim
        self.action_dim = action_dim

        self.fc1 = nn.Linear(state_dim, 250)
        self.fc1.weight.data = fanin_init(self.fc1.weight.data.size())

        self.fa1 = nn.Linear(action_dim, 250)
        self.fa1.weight.data = fanin_init(self.fa1.weight.data.size())

        self.fca1 = nn.Linear(500, 500)
        self.fca1.weight.data = fanin_init(self.fca1.weight.data.size())

        self.fca2 = nn.Linear(500, 1)
        self.fca2.weight.data.uniform_(-EPS, EPS)

    def forward(self, state, action):
        xs = torch.relu(self.fc1(state))
        xa = torch.relu(self.fa1(action))
        x = torch.cat((xs, xa), dim=1)
        x = torch.relu(self.fca1(x))
        vs = self.fca2(x)
        return vs


# ---Actor---#

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_limit_v, action_limit_w):
        super(Actor, self).__init__()
        self.state_dim = state_dim = state_dim
        self.action_dim = action_dim
        self.action_limit_v = action_limit_v
        self.action_limit_w = action_limit_w

        self.fa1 = nn.Linear(state_dim, 500)
        self.fa1.weight.data = fanin_init(self.fa1.weight.data.size())

        self.fa2 = nn.Linear(500, 500)
        self.fa2.weight.data = fanin_init(self.fa2.weight.data.size())

        self.fa3 = nn.Linear(500, action_dim)
        self.fa3.weight.data.uniform_(-EPS, EPS)

    def forward(self, state):
        x = torch.relu(self.fa1(state))
        x = torch.relu(self.fa2(x))
        action = self.fa3(x)
        # print("before actfun : ", "v_vel : ", action[0], " a_vel : ", action[0])
        if state.shape <= torch.Size([self.state_dim]):
            action[0] = torch.sigmoid(action[0]) * self.action_limit_v
            action[1] = torch.tanh(action[1]) * self.action_limit_w
        else:
            action[:, 0] = torch.sigmoid(action[:, 0]) * self.action_limit_v
            action[:, 1] = torch.tanh(action[:, 1]) * self.action_limit_w
        return action


# ---Where the train is made---#

class Trainer:

    def __init__(self, state_dim, action_dim, action_limit_v, action_limit_w, ACTION_DIMENSION):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_limit_v = action_limit_v
        self.action_limit_w = action_limit_w

        self.actor = Actor(self.state_dim, self.action_dim, self.action_limit_v, self.action_limit_w)
        self.target_actor = Actor(self.state_dim, self.action_dim, self.action_limit_v, self.action_limit_w)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), LEARNING_RATE)

        self.critic = Critic(self.state_dim, self.action_dim)
        self.target_critic = Critic(self.state_dim, self.action_dim)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), LEARNING_RATE)

        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)

    def get_action(self, state):
        state = torch.from_numpy(state)
        action = self.actor.forward(state).detach()  # actor net 기반
        return action.data.numpy()


    def load_models(self, ensemble, episode):
        self.actor.load_state_dict(torch.load(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/test model/' + str(ensemble) + '/' + str(episode) + '_actor.pt'))
        self.critic.load_state_dict(torch.load(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/test model/' + str(ensemble) + '/' + str(episode) + '_critic.pt'))
        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)
        print('***Models load***')


if __name__ == '__main__':
    rospy.init_node('ddpg_stage_4')
    env = Env(action_dim=ACTION_DIMENSION)
    goal = False
    success_list = []
    past_action = np.zeros(ACTION_DIMENSION)
    trainer = Trainer(STATE_DIMENSION, ACTION_DIMENSION, ACTION_V_MAX, ACTION_W_MAX, ACTION_DIMENSION)
    trainer.load_models(ENSEMBLE, EPISODE)

    for ep in range(MAX_EPISODES):
        print("========== Trial " + str(ep) + " ==========") 
        done = False
        if not goal:
            state, prev_cord = env.reset()
        goal = False

        original_rewards = 0.
        new_rewards = 0.
        temp_list = []

        for step in range(MAX_STEPS):
            state = np.float32(state)
            action = trainer.get_action(state)
            
            # (22.07.21 park) Reward 명 변경
            next_state, _, _, done, goalbox, _ = env.step(action, past_action)
            
            past_action = action            
            next_state = np.float32(next_state)
     
             # (22.07.22. kwon) reward_mode 별 ram 에 추가해야하는 immediate reward 로 list 생성 -

            state = copy.deepcopy(next_state)
            if goalbox:
                goal = True
                print("========== Success ==========")
                break
                
            if done or step == MAX_STEPS - 1:
                print("========== Failed ==========")
                break
        
        if goal:
            success_list.append(1)
        else:
            success_list.append(0)

print('success ratio : ', np.sum(success_list)/len(success_list) * 100)
