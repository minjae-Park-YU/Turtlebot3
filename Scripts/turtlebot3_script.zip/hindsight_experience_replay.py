#!/home/ubuntu/anaconda3/envs/tbtorch/bin/python3
# Developer: Minjae Park #

import math

goal_reward = 500
collision_reward = -550

HER_return = True

def newReward(prev_cord, cord, step, reward_mode):  # for HER
    prev_x = prev_cord[0]
    prev_y = prev_cord[1]
    current_x = cord[0]
    current_y = cord[1]
    goal_x = cord[2]
    goal_y = cord[3]
    newgoal_x = cord[4]
    newgoal_y = cord[5]
    # print("new_goal in newReward : " + str(newgoal_x) + ", " + str(newgoal_y))
    newgoal_box = False
    # print("current x : ", current_x)
    # print("current y : ", current_y)
    # print("goal x : ", newgoal_x)
    # print("goal y : ", newgoal_y)

    past_distance = round(math.hypot(newgoal_x - prev_x, newgoal_y - prev_y), 2)
    current_distance = round(math.hypot(newgoal_x - current_x, newgoal_y - current_y), 2)
    # print("newReward_current_distance : " + str(current_distance))
    distance_rate = (past_distance - current_distance)

    # (22.07.21. park) Reward mode에 따라 HER에 적용되는 Reward 계산방식 작성
    if reward_mode == 1:
        if distance_rate > 0:
            reward = 200. * distance_rate
        elif distance_rate <= 0:
            reward = -8.

    elif reward_mode == 2:
        reward = -1  # 1 Step 마다 -1의 Reward


    elif reward_mode == 3:
        reward = -1 * step  # 1 Step 마다 -1의 Reward

	# (22.07.22. kwon) reward mode 에 상관없이 아래 조건문이 사용되므로 조건문 밖에서 한 번만 실행하는 것으로 변경
    if current_distance < 0.15:  # 목적지에 도달했을 시 500점 추가, HER을 적용하기 위해
		# (22.07.20. kwon) 실제 보상과 일치시키기 위해 reward += 500 으로 수정
		# (22.07.22. kwon) 위 사항 재수정. immediate reward 이므로 += 에서 = 으로 수정
        reward = goal_reward  # 충돌 직전의 좌표를 목적지로 생각하기 때문에, 충돌 리워드는 없음
        newgoal_box = True

    goal_angle = math.atan2(goal_y - current_y, goal_x - current_x)
    new_goal_angle = math.atan2(newgoal_y - current_y, newgoal_x - current_x)

    return reward, current_distance, new_goal_angle - goal_angle, newgoal_box


# (22.07.20 kwon) setHER 함수 주석 추가
# temp_list : HER 설정을 위한 list
# step : 과거 몇 step 까지 HER 에 사용할지를 결정하는 변수
def setHER(ram, temp_list, step, reward_mode, HER_mode):
    if HER_mode == "pass":
        pass
    else:
        if HER_mode == "distance":
            HER_Distance = step
            # HER 적용하는 과정에서 Step에 따른 거리 계산 부분1
            terminal_state = False
            HER_current_distance = 0
            HER_Step = 0
            past_min_LDS = 0
            idx = -1
            HER_FLAG = False

            for i in range(len(temp_list[:])-1, 1, -1): # (23.03.16. park) 제자리에서 돌면 거리 측정이 안됨
                #print(abs(temp_list[i][6][0][0]))
                #print(abs(temp_list[i-1][6][0][0]))
                HER_current_distance += math.hypot(abs(temp_list[i][6][0][0] - temp_list[i-1][6][0][0]), abs(temp_list[i][6][0][1] - temp_list[i-1][6][0][1]))         # Step 간의 거리를 계산하여 모두 더하면 궤적의 길이가 됨
                #print("Current distance: ", current_distance)
                if HER_current_distance > HER_distance:
                    HER_FLAG = True
                    idx = i
                    break


            if HER_FLAG: 
                # (22.07.20 kwon) 조건문 주석 추가
                # temp_list[-1][3] : 충돌인 경우 확인 (충돌 = True)
                # len(temp_list[:]) > step   :  (전체스텝 - step) 에 대해 HER 적용이 가능한지 확인
                # if temp_list[-1][3] and len(temp_list[:]) > step:
                print("modified goal data saving...")
                # (22.07.20. kwon) new_goal 주석 추가
                new_goal_x = temp_list[-step][6][0][0]  # 전체스텝 - step 의 위치를 new_goal 로 설정
                new_goal_y = temp_list[-step][6][0][1]

                HER_Step = len(temp_list[:])-idx-1 # 현재 적용 중인 HER step(저장용)

                print("new_goal : " + str(new_goal_x) + ", " + str(new_goal_y))

                for i in range(len(temp_list[:]) - step):  # 전체스텝 - step 만큼 반복
                    st = temp_list[i][0]  # state
                    act = temp_list[i][1]  # action
                    n_st = temp_list[i][2]  # next state
                    dn = temp_list[i][3]  # done
                    prev_cord = temp_list[i][4]  # prev_cord
                    gb = temp_list[i][5]  # goalbox
                    # (22.07.22 kwon) cd 및 n_cd 생성방법 변경. 기존 방식의 경우 각 리스트가 초기화 되지 않는 문제 발생
                    cd = list(range(6))
                    n_cd = list(range(6))

                    cd[0] = temp_list[i][6][0][0]
                    cd[1] = temp_list[i][6][0][1]
                    cd[2] = temp_list[i][6][0][2]
                    cd[3] = temp_list[i][6][0][3]
                    cd[4] = new_goal_x
                    cd[5] = new_goal_y

                    # print("new_goal in cd : ", cd)

                    # print("Cd : ", temp_list[i + 1][6][0])
                    # print("n_cd : ", n_cd[0])

                    n_cd[0] = temp_list[i + 1][6][0][0]
                    n_cd[1] = temp_list[i + 1][6][0][1]
                    n_cd[2] = temp_list[i + 1][6][0][2]
                    n_cd[3] = temp_list[i + 1][6][0][3]
                    n_cd[4] = new_goal_x
                    n_cd[5] = new_goal_y

                    new_reward, current_distance, diff_goal_angle, n_goal_box = newReward(prev_cord, cd, i, reward_mode)
                    st[-1] = current_distance
                    st[-2] = diff_goal_angle + st[-2]

                    _, n_current_distance, n_diff_goal_angle, _ = newReward(temp_list[i + 1][4], n_cd, i + 1, reward_mode)
                    n_st[-1] = n_current_distance
                    n_st[-2] = n_diff_goal_angle + n_st[-2]

                    if n_goal_box:
                        print('setHER goal step : ' + str(i))  # (22.07.22 kwon) HER 제대로 되었는지 확인을 위함
                        for k in range(3):
                            if HER_mode == "Dynamic":
                                ram.add(st, act, new_reward, n_st, dn, mode="HER")
                            else:
                                ram.add(st, act, new_reward, n_st, dn)
                        break
                    else:
                        if HER_mode == "Dynamic":         
                            ram.add(st, act, new_reward, n_st, dn, mode="HER")
                        else:
                            ram.add(st, act, new_reward, n_st, dn)
                    del cd, n_cd

            if HER_return:
                return HER_Step, HER_current_distance
                
        else:
            HER_current_distance = 0
            step_count = 0
            idx = -1
            while step_count <= step:
                HER_current_distance += math.hypot(abs(temp_list[idx][6][0][0] - temp_list[idx-1][6][0][0]), abs(temp_list[idx][6][0][1] - temp_list[idx-1][6][0][1]))
                step_count += 1
                idx -= 1
            # (22.07.20 kwon) 조건문 주석 추가
            # temp_list[-1][3] : 충돌인 경우 확인 (충돌 = True)
            # len(temp_list[:]) > step   :  (전체스텝 - step) 에 대해 HER 적용이 가능한지 확인
            # if temp_list[-1][3] and len(temp_list[:]) > step:
            print("modified goal data saving...")
            # (22.07.20. kwon) new_goal 주석 추가
            new_goal_x = temp_list[-step][6][0][0]  # 전체스텝 - step 의 위치를 new_goal 로 설정
            new_goal_y = temp_list[-step][6][0][1]

            print("new_goal : " + str(new_goal_x) + ", " + str(new_goal_y))

            for i in range(len(temp_list[:]) - step):  # 전체스텝 - step 만큼 반복
                st = temp_list[i][0]  # state
                act = temp_list[i][1]  # action
                n_st = temp_list[i][2]  # next state
                dn = temp_list[i][3]  # done
                prev_cord = temp_list[i][4]  # prev_cord
                gb = temp_list[i][5]  # goalbox
                # (22.07.22 kwon) cd 및 n_cd 생성방법 변경. 기존 방식의 경우 각 리스트가 초기화 되지 않는 문제 발생
                cd = list(range(6))
                n_cd = list(range(6))

                cd[0] = temp_list[i][6][0][0]
                cd[1] = temp_list[i][6][0][1]
                cd[2] = temp_list[i][6][0][2]
                cd[3] = temp_list[i][6][0][3]
                cd[4] = new_goal_x
                cd[5] = new_goal_y

                # print("new_goal in cd : ", cd)

                # print("Cd : ", temp_list[i + 1][6][0])
                # print("n_cd : ", n_cd[0])

                n_cd[0] = temp_list[i + 1][6][0][0]
                n_cd[1] = temp_list[i + 1][6][0][1]
                n_cd[2] = temp_list[i + 1][6][0][2]
                n_cd[3] = temp_list[i + 1][6][0][3]
                n_cd[4] = new_goal_x
                n_cd[5] = new_goal_y

                new_reward, current_distance, diff_goal_angle, n_goal_box = newReward(prev_cord, cd, i, reward_mode)
                st[-1] = current_distance
                st[-2] = diff_goal_angle + st[-2]

                _, n_current_distance, n_diff_goal_angle, _ = newReward(temp_list[i + 1][4], n_cd, i + 1, reward_mode)
                n_st[-1] = n_current_distance
                n_st[-2] = n_diff_goal_angle + n_st[-2]

                if n_goal_box:
                    print('setHER goal step : ' + str(i))  # (22.07.22 kwon) HER 제대로 되었는지 확인을 위함
                    for k in range(3):
                        if HER_mode == "Dynamic":
                            ram.add(st, act, new_reward, n_st, dn, mode="HER")
                        else:
                            ram.add(st, act, new_reward, n_st, dn)
                    break
                else:
                    if HER_mode == "Dynamic":         
                        ram.add(st, act, new_reward, n_st, dn, mode="HER")
                    else:
                        ram.add(st, act, new_reward, n_st, dn)
                del cd, n_cd 

        if HER_return:
            return step, HER_current_distance