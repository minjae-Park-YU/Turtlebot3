#!/home/ubuntu/anaconda3/envs/tbtorch/bin/python3
# Authors: Junior Costa de Jesus #
# Deveoper: Minjae Park #

import rospy
import os
import numpy as np
import random
import time
import sys
import copy
import pandas as pd
import torch
import torch.nn.functional as F
import torch.nn as nn

from collections import deque
from std_msgs.msg import Float32
from environment_stage_3 import Env
from collections import deque

# (22.08.11 park) 사용 파라미터 한번에 관리하도록 구조 변경
# (22.07.21 park) reward 쉽게 변경하도록 모드 설정
reward_dict = {1: "Immediate, Original", 2: "Immediate, New", 3: "Accumulate, New"}
stage_dict = {1: "Vanilla", 2: "Fixed Obstacle"}
reward_mode = 1
stage_mode = 1
experiment = "Making Offline Dataset"

ENSEMBLE = 5
MAX_EPISODES = 1001
MAX_STEPS = 300
MAX_BUFFER = 20000
rewards_all_episodes = []

ACTION_DIMENSION = 2
ACTION_V_MAX = 0.22  # m/s
ACTION_W_MAX = 2.    # rad/s
linear_x = 0
angular_y = 0

# (22.07.22 kwon) 성공/충돌 시 보상 변수로 설정
# goal reward / collision reward
goal_reward = 500
collision_reward = -550

# (22.08.11 park) Stage 별 파라미터 변경하도록 함
world = 'stage_3'
SCAN_RANGE = 10
STATE_DIMENSION = SCAN_RANGE + ACTION_DIMENSION + 4

if reward_mode == 1:
    print("******************* reward mode : ", reward_dict[1], " ********************")
if reward_mode == 2:
    print("******************* reward mode : ", reward_dict[2], " ********************")
if reward_mode == 3:
    print("******************* reward mode : ", reward_dict[3], " ********************")


# 직접 조종하는 과정의 속도를 받아오기 위한 Callback 함수
def get_teleop_velocity(cmd_vel):
    global action
    l_vel = cmd_vel.linear.x
    a_vel = cmd_vel.angular.z
    action = [l_vel, a_vel]
    #rospy.loginfo(velocity)
    
rospy.Subscriber('cmd_vel', Twist, queue_size=5, callback=get_teleop_velocity)

# ---Directory Path---#
dirPath = os.path.dirname(os.path.realpath(__file__))


# ---Ornstein-Uhlenbeck Noise for action---#

class OUNoise(object):
    def __init__(self, action_space, mu=0.0, theta=0.15, max_sigma=0.3, min_sigma=0.2, decay_period=100000):
        self.mu = mu
        self.theta = theta
        self.sigma = max_sigma
        self.max_sigma = max_sigma
        self.min_sigma = min_sigma
        self.decay_period = decay_period
        self.action_dim = action_space
        self.reset()

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def evolve_state(self):
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.random.randn(self.action_dim)
        self.state = x + dx
        return self.state

    def get_noise(self, t=0):
        ou_state = self.evolve_state()
        decaying = float(float(t) / self.decay_period)
        self.sigma = max(self.sigma - (self.max_sigma - self.min_sigma) * min(1.0, decaying), self.min_sigma)
        return ou_state


# ---Memory Buffer---#

class MemoryBuffer:
    def __init__(self, size):
        self.buffer = deque(maxlen=size)
        self.maxSize = size
        self.len = 0

    def sample(self, count):
        batch = []
        count = min(count, self.len)
        batch = random.sample(self.buffer, count)

        s_array = np.float32([array[0] for array in batch])
        a_array = np.float32([array[1] for array in batch])
        r_array = np.float32([array[2] for array in batch])
        new_s_array = np.float32([array[3] for array in batch])
        dn_array = np.float32([array[3] for array in batch])

        return s_array, a_array, r_array, new_s_array, dn_array

    def len(self):
        return self.len

    def add(self, s, a, r, new_s, dn):
        transition = (s, a, r, new_s, dn)
        self.len += 1
        if self.len > self.maxSize:
            self.len = self.maxSize
        self.buffer.append(transition)



noise = OUNoise(ACTION_DIMENSION)

if __name__ == '__main__':
    print("Start collecting the data")

    rospy.init_node('ddpg_stage_3')

    env = Env(action_dim=ACTION_DIMENSION)
    goal = False

    offline_data = {}
    offline_s = []
    offline_a = []
    offline_r = []
    offline_n_s = []
    offline_count = 0
    offline_data_final = False

    past_action = np.zeros(ACTION_DIMENSION)

    for ep in range(MAX_EPISODES):
        print("episode ", ep, " start")

        if ep == MAX_EPISODES - 1:
            offline_data_final = True
        done = False
        if not goal:
            state, prev_cord = env.reset()
        goal = False

        original_rewards = 0.
        new_rewards = 0.
        temp_list = []

        for step in range(MAX_STEPS):
            state = np.float32(state)

            # (22.07.21 park) Reward 명 변경
            next_state, original_reward, new_reward, done, goalbox, cord = env.step(action, past_action)
            
            offline_s.append(state)
            offline_a.append(action)
            offline_r.append(original_reward)
            offline_n_s.append(next_state)
            
            # print('action', action,'r',reward)
            past_action = action

            next_state = np.float32(next_state)

             # (22.07.22. kwon) reward_mode 별 ram 에 추가해야하는 immediate reward 로 list 생성 -
            reward_arg = [original_reward, new_reward, new_rewards]

            state = copy.deepcopy(next_state)
            prev_cord = copy.deepcopy(cord)
            
            
            if len(offline_s) > 1000000:
                offline_data = {'state' : offline_s, 'action' : offline_a, 'reward' : offline_r, 'next_state' : offline_n_s}
                df1_name = "offline_datasets ep" + str(ep) + " Ensemble " + str(ensemble) + " data num " + str(offline_count) + ".csv" 
                df1 =  pd.DataFrame(offline_data)
                if not os.path.exists(dirPath + "/Offline Datasets/" + world):
                    os.makedirs(dirPath + "/Offline Datasets/" + world)
                df1.to_csv(dirPath + "/Offline Datasets/" + world + "/" +df1_name) 
         
                offline_count += 1

                offline_s = []
                offline_a = []
                offline_r = []
                offline_n_s = []
            
            if done or step == MAX_STEPS - 1 or goalbox:
                break
        
        # 주행 성공했을 때만 저장하도록 만드는 부분
        # if goalbox:
        #     offline_data = {'state' : offline_s, 'action' : offline_a, 'reward' : offline_r, 'done' : offline_d, 'next_state' : offline_n_s}
        #     df_name = "offline_datasets ep" + str(ep) + ".csv" 
        #     df =  pd.DataFrame(offline_data)
        #     if not os.path.exists(dirPath + "/Offline Datasets/" + world):
        #         os.makedirs(dirPath + "/Offline Datasets/" + world)
        #     df.to_csv(dirPath + "/Offline Datasets/" + world + "/" +df_name) 

        # 모든 데이터 저장
        if offline_data_final:
            offline_data = {'state' : offline_s, 'action' : offline_a, 'reward' : offline_r, 'next_state' : offline_n_s}
            df1_name = "offline_datasets ep" + str(ep) + " Ensemble " + str(ensemble) + " data num " + str(offline_count) + ".csv" 
            df1 =  pd.DataFrame(offline_data)
            if not os.path.exists(dirPath + "/Offline Datasets/" + world):
                os.makedirs(dirPath + "/Offline Datasets/" + world)
            df1.to_csv(dirPath + "/Offline Datasets/" + world + "/" +df1_name) 
                
            print("data saving completed!!")
    del ram

print('Completed Training')
