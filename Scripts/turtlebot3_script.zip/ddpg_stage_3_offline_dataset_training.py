#!/home/ubuntu/anaconda3/envs/tbtorch/bin/python3
# Authors: Junior Costa de Jesus #
# Developer: Minjae Park #

import rospy
import os
import numpy as np
import random
import time
import sys
import copy
import pandas as pd
import torch
import torch.nn.functional as F
import torch.nn as nn

from collections import deque
from std_msgs.msg import Float32
from environment_stage_3 import Env
from collections import deque

#offline data
offline_states = []
offline_actions = []
offline_rewards = []
offline_next_states = []

OFFLINE_DATA = []
offline_path = "/home/ubuntu/catkin_ws/src/turtlebot3_ddpg/src/Offline_Datasets/stage_3/*.csv"
offline_csvs = glob.glob(offline_path)

for file_name in offline_csvs:
    temp_csv = pd.read_csv(file_name)
    for i in range(len(temp_csv['state'])):
        temp_state = temp_csv['state'][i].replace("\n", "")
        temp_state = temp_state.replace("[", "")
        temp_state = temp_state.replace("]", "")
        offline_states.append(temp_state.split())
        temp_action = temp_csv['action'][i].replace("[", "")
        temp_action = temp_action.replace("]", "")
        temp_action = temp_action.replace(",", "")
        offline_actions.append(temp_action.split())
        offline_rewards.append(temp_csv['reward'][i])
        temp_next_state = temp_csv['next_state'][i].replace("\n", "")
        temp_next_state = temp_next_state.replace("[", "")
        temp_next_state = temp_next_state.replace("]", "")
        offline_next_states.append(temp_next_state.split())
      
# (22.08.11 park) 사용 파라미터 한번에 관리하도록 구조 변경
# (22.07.21 park) reward 쉽게 변경하도록 모드 설정
experiment = "Original"
ENSEMBLE = 0

exploration_decay_rate = 0.001
BATCH_SIZE = 2000  # 256 * 2
LEARNING_RATE = 0.001
GAMMA = 0.99
TAU = 0.001

MAX_EPISODES = 1001
MAX_STEPS = 300
MAX_BUFFER = 1000000

EPS = 0.003 # Critic weight 초기화 관련 파라미터

ACTION_DIMENSION = 2
ACTION_V_MAX = 0.22  # m/s
ACTION_W_MAX = 2.    # rad/s

# (22.07.22 kwon) 성공/충돌 시 보상 변수로 설정
# goal reward / collision reward
goal_reward = 500
collision_reward = -550

# (22.08.11 park) Stage 별 파라미터 변경하도록 함
world = 'stage_3'
SCAN_RANGE = 10
STATE_DIMENSION = SCAN_RANGE + ACTION_DIMENSION + 4


if reward_mode == 1:
    print("******************* reward mode : ", reward_dict[1], " ********************")
if reward_mode == 2:
    print("******************* reward mode : ", reward_dict[2], " ********************")
if reward_mode == 3:
    print("******************* reward mode : ", reward_dict[3], " ********************")


# ---Directory Path---#
dirPath = os.path.dirname(os.path.realpath(__file__))


# ---Functions to make network updates---#

def soft_update(target, source, tau):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)


def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)


# ---Ornstein-Uhlenbeck Noise for action---#

class OUNoise(object):
    def __init__(self, action_space, mu=0.0, theta=0.15, max_sigma=0.3, min_sigma=0.2, decay_period=100000):
        self.mu = mu
        self.theta = theta
        self.sigma = max_sigma
        self.max_sigma = max_sigma
        self.min_sigma = min_sigma
        self.decay_period = decay_period
        self.action_dim = action_space
        self.reset()

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def evolve_state(self):
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.random.randn(self.action_dim)
        self.state = x + dx
        return self.state

    def get_noise(self, t=0):
        ou_state = self.evolve_state()
        decaying = float(float(t) / self.decay_period)
        self.sigma = max(self.sigma - (self.max_sigma - self.min_sigma) * min(1.0, decaying), self.min_sigma)
        return ou_state


# ---Critic--#

def fanin_init(size, fanin=None):
    fanin = fanin or size[0]
    v = 1. / np.sqrt(fanin)
    return torch.Tensor(size).uniform_(-v, v)


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()

        self.state_dim = state_dim = state_dim
        self.action_dim = action_dim

        self.fc1 = nn.Linear(state_dim, 250)
        self.fc1.weight.data = fanin_init(self.fc1.weight.data.size())

        self.fa1 = nn.Linear(action_dim, 250)
        self.fa1.weight.data = fanin_init(self.fa1.weight.data.size())

        self.fca1 = nn.Linear(500, 500)
        self.fca1.weight.data = fanin_init(self.fca1.weight.data.size())

        self.fca2 = nn.Linear(500, 1)
        self.fca2.weight.data.uniform_(-EPS, EPS)

    def forward(self, state, action):
        xs = torch.relu(self.fc1(state))
        xa = torch.relu(self.fa1(action))
        x = torch.cat((xs, xa), dim=1)
        x = torch.relu(self.fca1(x))
        vs = self.fca2(x)
        return vs


# ---Actor---#

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_limit_v, action_limit_w):
        super(Actor, self).__init__()
        self.state_dim = state_dim = state_dim
        self.action_dim = action_dim
        self.action_limit_v = action_limit_v
        self.action_limit_w = action_limit_w

        self.fa1 = nn.Linear(state_dim, 500)
        self.fa1.weight.data = fanin_init(self.fa1.weight.data.size())

        self.fa2 = nn.Linear(500, 500)
        self.fa2.weight.data = fanin_init(self.fa2.weight.data.size())

        self.fa3 = nn.Linear(500, action_dim)
        self.fa3.weight.data.uniform_(-EPS, EPS)

    def forward(self, state):
        x = torch.relu(self.fa1(state))
        x = torch.relu(self.fa2(x))
        action = self.fa3(x)
        # print("before actfun : ", "v_vel : ", action[0], " a_vel : ", action[0])
        if state.shape <= torch.Size([self.state_dim]):
            action[0] = torch.sigmoid(action[0]) * self.action_limit_v
            action[1] = torch.tanh(action[1]) * self.action_limit_w
        else:
            action[:, 0] = torch.sigmoid(action[:, 0]) * self.action_limit_v
            action[:, 1] = torch.tanh(action[:, 1]) * self.action_limit_w
        return action


# ---Memory Buffer---#

class MemoryBuffer:
    def __init__(self, size):
        self.buffer = deque(maxlen=size)
        self.maxSize = size
        self.len = 0

    def sample(self, count):
        batch = []
        count = min(count, self.len)
        batch = random.sample(self.buffer, count)

        s_array = np.float32([array[0] for array in batch])
        a_array = np.float32([array[1] for array in batch])
        r_array = np.float32([array[2] for array in batch])
        new_s_array = np.float32([array[3] for array in batch])
        dn_array = np.float32([array[3] for array in batch])

        return s_array, a_array, r_array, new_s_array, dn_array

    def len(self):
        return self.len

    def add(self, s, a, r, new_s, dn):
        transition = (s, a, r, new_s, dn)
        self.len += 1
        if self.len > self.maxSize:
            self.len = self.maxSize
        self.buffer.append(transition)

# ---Where the train is made---#

class Trainer:

    def __init__(self, state_dim, action_dim, action_limit_v, action_limit_w, ram, ACTION_DIMENSION):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_limit_v = action_limit_v
        self.action_limit_w = action_limit_w
        # print('w',self.action_limit_w)
        self.ram = ram
        # self.iter = 0
        self.noise = OUNoise(ACTION_DIMENSION)

        self.actor = Actor(self.state_dim, self.action_dim, self.action_limit_v, self.action_limit_w)
        self.target_actor = Actor(self.state_dim, self.action_dim, self.action_limit_v, self.action_limit_w)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), LEARNING_RATE)

        self.critic = Critic(self.state_dim, self.action_dim)
        self.target_critic = Critic(self.state_dim, self.action_dim)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), LEARNING_RATE)

        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)

    def get_action(self, state):
        state = torch.from_numpy(state)
        action = self.actor.forward(state).detach()  # actor net 기반
        return action.data.numpy()

    def optimizer(self):
        s_sample, a_sample, r_sample, new_s_sample = ram.sample(BATCH_SIZE)

        s_sample = torch.from_numpy(s_sample)
        a_sample = torch.from_numpy(a_sample)
        r_sample = torch.from_numpy(r_sample)
        new_s_sample = torch.from_numpy(new_s_sample)

        # -------------- optimize critic

        a_target = self.target_actor.forward(new_s_sample).detach()
        next_value = torch.squeeze(self.target_critic.forward(new_s_sample, a_target).detach())
        # y_exp = r _ gamma*Q'(s', P'(s'))
        y_expected = r_sample + GAMMA * next_value
        # y_pred = Q(s,a)
        y_predicted = torch.squeeze(self.critic.forward(s_sample, a_sample))
        # -------Publisher of Vs------
        # print(self.qvalue, torch.max(self.qvalue))
        # ----------------------------
        loss_critic = F.smooth_l1_loss(y_predicted, y_expected)

        self.critic_optimizer.zero_grad()
        loss_critic.backward()
        self.critic_optimizer.step()

        # ------------ optimize actor
        pred_a_sample = self.actor.forward(s_sample)
        loss_actor = -1 * torch.sum(self.critic.forward(s_sample, pred_a_sample))

        self.actor_optimizer.zero_grad()
        loss_actor.backward()

        self.actor_optimizer.step()
        # (22.08.15. park) loss 출력 깔끔히 나오도록 변경
        #print("==============================================")
        #print()
        #print("actor loss : ", loss_actor.detach().numpy().tolist(), " critic_loss : ", loss_critic.detach().numpy().tolist())
        #print()
        #print("==============================================")
        soft_update(self.target_actor, self.actor, TAU)
        soft_update(self.target_critic, self.critic, TAU)
        
        return loss_actor.detach().numpy().tolist(), loss_critic.detach().numpy().tolist()

    # (22.08.11. park) 실험 별, 에피소드 별 모델 저장하도록 변경
    def save_models(self, ENSEMBLE, episode):
        if not os.path.exists(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/'):
                os.makedirs(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/')
        torch.save(self.target_actor.state_dict(),
                   dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/' + str(episode) + '_actor.pt')
        torch.save(self.target_critic.state_dict(),
                   dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/' + str(episode) + '_critic.pt')
        print('****Models saved***')

    def load_models(self, ENSEMBLE, episode):
        self.actor.load_state_dict(torch.load(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/' + str(episode) + '_actor.pt'))
        self.critic.load_state_dict(torch.load(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/model/' + str(ENSEMBLE) + '/' + str(episode) + '_critic.pt'))
        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)
        print('***Models load***')


# ---Mish Activation Function---#
def mish(x):
    '''
        Mish: A Self Regularized Non-Monotonic Neural Activation Function
        https://arxiv.org/abs/1908.08681v1
        implemented for PyTorch / FastAI by lessw2020
        https://github.com/lessw2020/mish
        param:
            x: output of a layer of a neural network
        return: mish activation function
    '''
    return x * (torch.tanh(F.softplus(x)))


ram = MemoryBuffer(MAX_BUFFER)

for i in range(len(offline_states)):
    ram.add(offline_states[i], offline_actions[i], offline_rewards[i], offline_next_states[i])

# ---Run agent---#

if is_training:
    var_v = ACTION_V_MAX * .5
    var_w = ACTION_W_MAX * 2 * .5
else:
    var_v = ACTION_V_MAX * 0.10
    var_w = ACTION_W_MAX * 0.10

print('State Dimensions: ' + str(STATE_DIMENSION))
print('Action Dimensions: ' + str(ACTION_DIMENSION))
print('Action Max: ' + str(ACTION_V_MAX) + ' m/s and ' + str(ACTION_W_MAX) + ' rad/s')
# ram = MemoryBuffer(MAX_BUFFER)
# trainer = Trainer(STATE_DIMENSION, ACTION_DIMENSION, ACTION_V_MAX, ACTION_W_MAX, ram)

noise = OUNoise(ACTION_DIMENSION)
reward_list = []
new_reward_list = []
# trainer.load_models(140)rd

if __name__ == '__main__':
    rospy.init_node('ddpg_stage_3')
    env = Env(action_dim=ACTION_DIMENSION)
    goal = False
   # for ensemble in range(10):
    actor_loss = [0]
    critic_loss = [0]

    past_action = np.zeros(ACTION_DIMENSION)
    trainer = Trainer(STATE_DIMENSION, ACTION_DIMENSION, ACTION_V_MAX, ACTION_W_MAX, ram, ACTION_DIMENSION)
    
    print("starting training!!")
    for ep in range(MAX_EPISODES):
        #actor_l=float(actor_l[i])
        #critic_l=float(critic_l[i])
        actor_l, critic_l = trainer.optimizer()
        actor_loss.append(actor_l)

    df1_name = "actor_loss_ep" + str(ep) + " Ensemble " + str(ENSEMBLE) + ".csv"
    df2_name = "critic_loss_ep" + str(ep) + " Ensemble " + str(ENSEMBLE) + ".csv"
    df1 = pd.DataFrame(actor_loss, columns=['loss'])
    df2 = pd.DataFrame(critic_loss, columns=['loss'])
    if not os.path.exists(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/loss/' + "Ensemble " + str(ENSEMBLE) + '/'):
        os.makedirs(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/loss/' + "Ensemble " + str(ENSEMBLE) + '/')
    df3.to_csv(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/loss/' + "Ensemble " + str(ENSEMBLE) + '/' + df1_name)
    df4.to_csv(dirPath + '/DDPG Experiment/' + world + '/' + experiment + '/loss/' + "Ensemble " + str(ENSEMBLE) + '/' + df2_name)    
    
    for ep in range(MAX_EPISODES):
        print("========== Trial " + str(ep) + " ==========") 
        done = False
        if not goal:
            state, prev_cord = env.reset()
        goal = False

        original_rewards = 0.
        new_rewards = 0.
        temp_list = []

        for step in range(MAX_STEPS):
            state = np.float32(state)
            action = trainer.get_action(state)
            
            # (22.07.21 park) Reward 명 변경
            next_state, _, _, done, goalbox, _ = env.step(action, past_action)
            
            past_action = action            
            next_state = np.float32(next_state)
     
             # (22.07.22. kwon) reward_mode 별 ram 에 추가해야하는 immediate reward 로 list 생성 -

            state = copy.deepcopy(next_state)
            if goalbox:
                goal = True
                print("========== Success ==========")
                break
                
            if done or step == MAX_STEPS - 1:
                print("========== Failed ==========")
                break
        
        if goal:
            success_list.append(1)
        else:
            success_list.append(0)

print('success ratio : ', np.sum(success_list)/len(success_list) * 100)